class Binary < ActiveRecord::Base
end