CREATE TABLE courses (
 id int NOT NULL PRIMARY KEY,
 name varchar(255) NOT NULL
);

