CREATE TABLE courses (
  id integer DEFAULT unique,
  name varchar(100)
);
