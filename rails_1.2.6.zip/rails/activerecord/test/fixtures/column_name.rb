class ColumnName < ActiveRecord::Base
  def self.table_name () "colnametests" end
end