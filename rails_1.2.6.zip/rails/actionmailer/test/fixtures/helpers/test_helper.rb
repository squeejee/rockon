module TestHelper
  def test_format(text)
    "<em><strong><small>#{text}</small></strong></em>"
  end
end
