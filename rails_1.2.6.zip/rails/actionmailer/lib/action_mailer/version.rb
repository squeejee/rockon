module ActionMailer
  module VERSION #:nodoc:
    MAJOR = 1
    MINOR = 3
    TINY  = 6

    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
